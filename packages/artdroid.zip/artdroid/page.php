<?php include "single.php"; ?> 
<!-- Generated in <?php timer_stop(1); ?> seconds... -->