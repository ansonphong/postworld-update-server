<?php

require(__DIR__ . '/src/Httpful/Bootstrap.php');
\Httpful\Bootstrap::init();
