<?php

add_shortcode( 'i-subpages', 'pw_pagelist_shortcode' );
add_shortcode( 'i-siblings', 'pw_pagelist_shortcode' );

?>