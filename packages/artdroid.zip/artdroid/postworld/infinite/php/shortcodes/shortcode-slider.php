<?php

add_shortcode( 'i-slider', 'pw_slider_shortcode' );

?>