<?php

add_shortcode( 'callout', 'i_general_shortcode' );
add_shortcode( 'callout-xl', 'i_general_shortcode' );

?>