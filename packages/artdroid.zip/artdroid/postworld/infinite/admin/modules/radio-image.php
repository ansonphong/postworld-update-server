<label class="radio_image_select">
	<input name="<?php echo $vars['option_name']; ?>" type="radio" value="<?php echo $vars['option']['slug']; ?>" <?php echo $vars['checked']; ?> <?php echo $vars['attributes']; ?> />
	<img src="<?php echo $vars['option']['image'];?>">
</label>