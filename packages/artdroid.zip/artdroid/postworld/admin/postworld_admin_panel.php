<?php
function postworld_settings_display(){
?>
<?php wp_enqueue_style( 'admin_css' ); ?>

<h1>Postworld</h1>


<?php } ?>


<?php
function postworld_roles_settings_display(){
?>
<?php wp_enqueue_style( 'admin_css' ); ?>

<h1>Roles</h1>


<?php } ?>






