<?php
	// Blog Page
	include locate_template('views/archive/index.php'); ?>
<!-- Generated in <?php timer_stop(1); ?> seconds... -->