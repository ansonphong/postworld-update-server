<?php // Template Name: Home Page
	include "home.php";
?>