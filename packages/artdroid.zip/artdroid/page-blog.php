<?php // Template Name: Blog
	include "blog.php";
?>